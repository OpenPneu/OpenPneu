import sys
import matplotlib
import matplotlib.pyplot as plt
from pyqtgraph.Qt import QtCore, QtGui
import pyqtgraph as pg
from PyQt5 import QtGui as qtg
from PyQt5 import QtWidgets
from random import random
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.figure import Figure
import numpy as np
import time

# matplotlib.use('Qt5Agg')
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
class MplCanvas(FigureCanvasQTAgg):

    def __init__(self, parent=None, width=1, height=1, dpi=1):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        super(MplCanvas, self).__init__(self.fig)
    def updateFig(self):
        self.fig.canvas.draw()
    def clean(self):
        self.fig.clean()

class MainWindow(QtWidgets.QMainWindow):

    def __init__(self, PlotName = "Plot Monitor", *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        '''
        New code here
        '''
        #### Create Gui Elements ###########
        pg.setConfigOption('background', 'w')
        self.mainbox = QtGui.QWidget()
       
        self.setCentralWidget(self.mainbox)
        self.mainbox.setLayout(QtGui.QVBoxLayout())

        self.canvas = pg.GraphicsLayoutWidget()
        self.mainbox.layout().addWidget(self.canvas)
        

        # self.label = QtGui.QLabel()
        # # self.label.setFont(QtGui.QFont('Arial',5))
        
        # self.mainbox.layout().addWidget(self.label)

        #self.plotWindow is PlotItem object
        self.plotWindow = self.canvas.addPlot()
        # left = 100, top = 100
        # width = 600, height = 500
        self.plotWindow.resize(2048, 1500)
        #self.plotWindow.setGeometry(100, 100, 1024, 768)
        
        leg = self.plotWindow.addLegend()
        leg.setScale(1.0)           #legend size
        
        bottomAxis = self.plotWindow.getAxis('bottom')
        
        
        self.plotWindow.setXRange(0, 1000, padding=0)
        self.plotWindow.setYRange(-100, 100, padding=0)
        
        ############################################################
        ############################################################
        # pen1 = pg.mkPen(color='b', style=QtCore.Qt.SolidLine) 
        # pen1.setWidth(2)
        
        # pen2 = pg.mkPen(color='r', style=QtCore.Qt.SolidLine) 
        # pen2.setWidth(2)
        
        # pen5 = pg.mkPen(color='g', style=QtCore.Qt.SolidLine) 
        # pen5.setWidth(2)
        
        # pen3 = pg.mkPen(color=(0, 0, 0), style=QtCore.Qt.DashLine) 
        # pen3.setWidth(1.5)
        
        # pen4 = pg.mkPen(color=(0, 204, 102), style=QtCore.Qt.DashLine) 
        # pen4.setWidth(1.5)
        
        
        # self.h1 = self.plotWindow.plot(pen=pen1,name="Current Pressure")
        # self.h2 = self.plotWindow.plot(pen=pen2,name="Target Pressure")
        # self.h3 = self.plotWindow.plot(pen=pen3,name="Inflation Pump Flow Rate")
        # self.h4 = self.plotWindow.plot(pen=pen4,name="Deflation Pump Flow Rate")
        
        # self.h5 = self.plotWindow.plot(pen=pen5,name="Pressure Derivative")

        # self.x = np.linspace(0,999., num=1000)


        # labelStyleBottomX = {'color': '#000000', 'font-size': '22px'} #18 24 BIG
        # labelStyleLeftY = {'color': '#000000', 'font-size': '22px'}
        # labelStyleRightY = {'color': '#000000', 'font-size': '22px'}
        
        # self.plotWindow.setLabel(axis='left', text='Pressure (kPa)',**labelStyleLeftY)
        # self.plotWindow.setLabel(axis='bottom', text='Time Step (50 ms)',**labelStyleBottomX)
        # #self.plotWindow.setLabel(axis='top', text='top',**labelStyleBottomX)
        # #self.plotWindow.setLabel(axis='right', text='right',**labelStyleBottomX)
        # # self.plotWindow.showAxis('right')
        
       
        # ## create a new ViewBox, link the right axis to its coordinate system
        # p2 = pg.ViewBox()
        # p2.setRange(yRange =(-25000,25000))
        # self.plotWindow.showAxis('right')
        # self.plotWindow.scene().addItem(p2)
        # self.plotWindow.getAxis('right').linkToView(p2)
        # self.plotWindow.setLabel(axis='right', text = 'Flow Rate',**labelStyleRightY)
        
        # p2.setGeometry(self.plotWindow.vb.sceneBoundingRect())
        # p2.setXLink(self.plotWindow)
        
      
        # self.currentPressurelist = np.zeros([1000],dtype = float)
        # self.targetPressureylist = np.zeros([1000],dtype = float)
        # self.flowRateInflationlist = np.zeros([1000],dtype = float)
        # self.flowRateDeflationlist = np.zeros([1000],dtype = float)
        # self.pressureDerivativelist = np.zeros([1000],dtype = float)
        
        # self.setWindowTitle(PlotName)
        # self.setWindowIcon(qtg.QIcon('iconCat.jpg'))
        
        # self.setGeometry(100, 30, 1024, 768)
        
        ############################################################
        ############################################################
        
        pen1 = pg.mkPen(color=(0, 0, 255), style=QtCore.Qt.SolidLine) 
        pen1.setWidth(1.5)
        
        pen2 = pg.mkPen(color=(255, 0, 0), style=QtCore.Qt.SolidLine) 
        pen2.setWidth(1.5)
        

        pen3 = pg.mkPen(color=(0, 0, 0), style=QtCore.Qt.SolidLine) 
        pen3.setWidth(1.5)
        
        pen4 = pg.mkPen(color=(0, 204, 102), style=QtCore.Qt.SolidLine) 
        pen4.setWidth(1.5)
        
        pen5 = pg.mkPen(color=(0, 255, 0), style=QtCore.Qt.SolidLine) 
        pen5.setWidth(1.5)
        
        
        pen6 = pg.mkPen(color=(0, 0, 255), style=QtCore.Qt.DashLine) 
        pen6.setWidth(1.5)
        
        pen7 = pg.mkPen(color=(255, 0, 0), style=QtCore.Qt.DashLine) 
        pen7.setWidth(1.5)
        

        pen8 = pg.mkPen(color=(0, 0, 0), style=QtCore.Qt.DashLine) 
        pen8.setWidth(1.5)
        
        pen9 = pg.mkPen(color=(0, 204, 102), style=QtCore.Qt.DashLine) 
        pen9.setWidth(1.5)
        
        pen10 = pg.mkPen(color=(0, 255, 0), style=QtCore.Qt.DashLine) 
        pen10.setWidth(1.5)
        
        
        self.h1 = self.plotWindow.plot(pen=pen1,name="Current Pressure 1")
        self.h2 = self.plotWindow.plot(pen=pen2,name="Current Pressure 2")
        self.h3 = self.plotWindow.plot(pen=pen3,name="Current Pressure 3")
        self.h4 = self.plotWindow.plot(pen=pen4,name="Current Pressure 4")
        self.h5 = self.plotWindow.plot(pen=pen5,name="Current Pressure 5")
        self.h6 = self.plotWindow.plot(pen=pen1,name="Current Pressure 6")
        self.h7 = self.plotWindow.plot(pen=pen2,name="Current Pressure 7")
        self.h8 = self.plotWindow.plot(pen=pen3,name="Current Pressure 8")
        self.h9 = self.plotWindow.plot(pen=pen4,name="Current Pressure 9")
        self.h10 = self.plotWindow.plot(pen=pen5,name="Current Pressure 10")

        self.x = np.linspace(0,999., num=1000)


        labelStyleBottomX = {'color': '#000000', 'font-size': '22px'} #18 24 BIG
        labelStyleLeftY = {'color': '#000000', 'font-size': '22px'}
        labelStyleRightY = {'color': '#000000', 'font-size': '22px'}
        
        self.plotWindow.setLabel(axis='left', text='Pressure (kPa)',**labelStyleLeftY)
        self.plotWindow.setLabel(axis='bottom', text='Time Step',**labelStyleBottomX)
        #self.plotWindow.setLabel(axis='top', text='top',**labelStyleBottomX)
        #self.plotWindow.setLabel(axis='right', text='right',**labelStyleBottomX)
        # self.plotWindow.showAxis('right')
        
       
        ## create a new ViewBox, link the right axis to its coordinate system
        # p2 = pg.ViewBox()
        # p2.setRange(yRange =(-25000,25000))
        # self.plotWindow.showAxis('right')
        # self.plotWindow.scene().addItem(p2)
        # self.plotWindow.getAxis('right').linkToView(p2)
        # self.plotWindow.setLabel(axis='right', text = 'Flow Rate',**labelStyleRightY)
        
        # p2.setGeometry(self.plotWindow.vb.sceneBoundingRect())
        # p2.setXLink(self.plotWindow)
        
      
        self.currentPressurelist = np.zeros([1000],dtype = float)
      
        self.currentPressurelist1 = np.zeros([1000],dtype = float)
        self.currentPressurelist2 = np.zeros([1000],dtype = float)
        self.currentPressurelist3 = np.zeros([1000],dtype = float)
        self.currentPressurelist4 = np.zeros([1000],dtype = float)
        self.currentPressurelist5 = np.zeros([1000],dtype = float)
        self.currentPressurelist6 = np.zeros([1000],dtype = float)
        self.currentPressurelist7 = np.zeros([1000],dtype = float)
        self.currentPressurelist8 = np.zeros([1000],dtype = float)
        self.currentPressurelist9 = np.zeros([1000],dtype = float)
        self.currentPressurelist10 = np.zeros([1000],dtype = float)
        
        self.targetPressureylist = np.zeros([1000],dtype = float)
        self.flowRateInflationlist = np.zeros([1000],dtype = float)
        self.flowRateDeflationlist = np.zeros([1000],dtype = float)
        self.pressureDerivativelist = np.zeros([1000],dtype = float)
        
        
        
        
        self.setWindowTitle(PlotName)
        self.setWindowIcon(qtg.QIcon('iconCat.jpg'))
        
        self.setGeometry(100, 30, 1024, 768)
        
        
        
        
        
        fps = 100
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.setInterval(1000 / fps)
        self.counter = 0
        
        self.timerCounter = 0
        print("Reach here")
        # xfont=QtGui.QFont()
        # xfont.setPixelSize(10)
        # self.plotWindow.getAxis("bottom").tickFont = xfont
        
    
    #original time cost: 55 ms -> too slow
    def updateOnce(self,currentPressure,targetPressure,flowRateInflation,flowRateDeflation,pressureDerivative):

        # #start = time.time()
        # self.currentPressurelist = np.roll(self.currentPressurelist, -1, axis=0)
        # self.currentPressurelist[999] = currentPressure
        
        # self.targetPressureylist = np.roll(self.targetPressureylist, -1, axis=0)
        # self.targetPressureylist[999] = targetPressure
        
        # self.flowRateInflationlist = np.roll(self.flowRateInflationlist, -1, axis=0)
                                               # #To recover the speed/fit the y axis
        # self.flowRateInflationlist[999] = flowRateInflation*1000.0/250.0

        # self.flowRateDeflationlist = np.roll(self.flowRateDeflationlist, -1, axis=0)
        # self.flowRateDeflationlist[999] = flowRateDeflation*1000.0/250.0
        
        # self.pressureDerivativelist = np.roll(self.pressureDerivativelist, -1, axis=0)
        # self.pressureDerivativelist[999] = pressureDerivative/10.0
        
        # self.h1.setData(self.currentPressurelist)
        # self.h2.setData(self.targetPressureylist)
        # self.h3.setData(self.flowRateInflationlist)
        # self.h4.setData(self.flowRateDeflationlist)
        # self.h5.setData(self.pressureDerivativelist)
        # #self.h32.setData(self.flowRateInflationlist)

        # #print("hello")
        # #end = time.time()
        # #print(f"Elaspse time of redrawing takes {(end - start)*1000.0} ms")
        
        # self.counter =  self.counter + 1
        
        # if self.counter >=50000:
            # self.counter = 10

        
        
        #start = time.time()
        self.currentPressurelist = np.roll(self.currentPressurelist, -1, axis=0)
        self.currentPressurelist[999] = currentPressure
        
        self.targetPressureylist = np.roll(self.targetPressureylist, -1, axis=0)
        self.targetPressureylist[999] = targetPressure
        
        self.flowRateInflationlist = np.roll(self.flowRateInflationlist, -1, axis=0)
                                               #To recover the speed/fit the y axis
        self.flowRateInflationlist[999] = flowRateInflation*1000.0/250.0

        self.flowRateDeflationlist = np.roll(self.flowRateDeflationlist, -1, axis=0)
        self.flowRateDeflationlist[999] = flowRateDeflation*1000.0/250.0
        
        self.pressureDerivativelist = np.roll(self.pressureDerivativelist, -1, axis=0)
        self.pressureDerivativelist[999] = pressureDerivative/10.0
        
        self.h1.setData(self.currentPressurelist)
        self.h2.setData(self.targetPressureylist)
        self.h3.setData(self.flowRateInflationlist)
        self.h4.setData(self.flowRateDeflationlist)
        self.h5.setData(self.pressureDerivativelist)
        #self.h32.setData(self.flowRateInflationlist)

        #print("hello")
        #end = time.time()
        #print(f"Elaspse time of redrawing takes {(end - start)*1000.0} ms")
        
        self.counter =  self.counter + 1
        
        if self.counter >=50000:
            self.counter = 10



    def updateCurrentPressure(self,currentPressureArray):
        self.currentPressurelist1 = np.roll(self.currentPressurelist1, -1, axis=0)
        self.currentPressurelist1[999] = currentPressureArray[0]
        
        self.currentPressurelist2 = np.roll(self.currentPressurelist2, -1, axis=0)
        self.currentPressurelist2[999] = currentPressureArray[1]
        
        self.currentPressurelist3 = np.roll(self.currentPressurelist3, -1, axis=0)
        self.currentPressurelist3[999] = currentPressureArray[2]
        
        self.currentPressurelist4 = np.roll(self.currentPressurelist4, -1, axis=0)
        self.currentPressurelist4[999] = currentPressureArray[3]
        
        self.currentPressurelist5 = np.roll(self.currentPressurelist5, -1, axis=0)
        self.currentPressurelist5[999] = currentPressureArray[4]
        
        self.currentPressurelist6 = np.roll(self.currentPressurelist6, -1, axis=0)
        self.currentPressurelist6[999] = currentPressureArray[5]
        
        self.currentPressurelist7 = np.roll(self.currentPressurelist7, -1, axis=0)
        self.currentPressurelist7[999] = currentPressureArray[6]
        
        self.currentPressurelist8 = np.roll(self.currentPressurelist8, -1, axis=0)
        self.currentPressurelist8[999] = currentPressureArray[7]
        
        self.currentPressurelist9 = np.roll(self.currentPressurelist9, -1, axis=0)
        self.currentPressurelist9[999] = currentPressureArray[8]
        
        self.currentPressurelist10 = np.roll(self.currentPressurelist10, -1, axis=0)
        self.currentPressurelist10[999] = currentPressureArray[9]
        
        
        self.h1.setData(self.currentPressurelist1)
        self.h2.setData(self.currentPressurelist2)
        self.h3.setData(self.currentPressurelist3)
        self.h4.setData(self.currentPressurelist4)
        self.h5.setData(self.currentPressurelist5)
        
        self.h6.setData(self.currentPressurelist1)
        self.h7.setData(self.currentPressurelist2)
        self.h8.setData(self.currentPressurelist3)
        self.h9.setData(self.currentPressurelist4)
        self.h10.setData(self.currentPressurelist5)
        #self.h32.setData(self.flowRateInflationlist)

        #print("hello")
        #end = time.time()
        #print(f"Elaspse time of redrawing takes {(end - start)*1000.0} ms")
        
        self.counter =  self.counter + 1
        
        if self.counter >=50000:
            self.counter = 10
    
    def startTimer(self):
        self.timer.start()
    
    def update(self):
        self.sc.axes.cla()
        
        examplex = self.counter
        currentPressure = random()*80
        targetPressure = random()*80
        flowRateInflation = random()*20
        flowRateDeflation = random()*20
        
        if self.counter>=50:
            self.currentPressurelist.pop(0)
            self.targetPressureylist.pop(0)
            self.flowRateInflationlist.pop(0)
            self.flowRateDeflationlist.pop(0)
            
        else:
            self.xlist.append(examplex)
            
        #current pressure place in exampley
        
        self.currentPressurelist.append(currentPressure)
        self.targetPressureylist.append(targetPressure)
        self.flowRateInflationlist.append(flowRateInflation)
        self.flowRateDeflationlist.append(flowRateDeflation)
 
        self.sc.axes.plot(self.xlist, self.currentPressurelist, label='Current Pressure')
        self.sc.axes.plot(self.xlist, self.targetPressureylist, label='Target Pressure')
        self.sc.axes.plot(self.xlist, self.flowRateInflationlist, label='Inflation Flowrate')
        self.sc.axes.plot(self.xlist, self.flowRateDeflationlist, label='Deflation Flowrate')
        
        self.sc.axes.set_xlim([0, 50])
        self.sc.axes.set_ylim([0, 100])
        self.sc.axes.legend(loc = 'upper right')
        self.sc.updateFig()
        self.counter =  self.counter + 1
        
    def Stop():
        self.timer.stop()
if __name__ == "__main__":   
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    app.exec_()