import sys
from PyQt5 import QtWidgets as qtw
from PyQt5 import QtCore as qtc
from PyQt5 import QtGui as qtg
from PyQt5.QtWidgets import *
from PyQt5.QtCore import QTimer, QDateTime, QThread,pyqtSignal,pyqtSlot,QMutex
import time
import numpy as np

import serial
import serial.tools.list_ports

import qdarkstyle 

class globalDataSet():
    def __init__(self):
        self.mutex = QMutex()
        self.currentP = np.zeros([10],dtype=float)
        self.targetP = np.zeros([10],dtype=float)
        self.inflationPump = np.zeros([10],dtype=float)
        self.deflationPump = np.zeros([10],dtype=float)
        self.pressureDerivative = np.zeros([10],dtype=float)


class Worker(qtc.QObject):
    def __init__(self):
        super(Worker,self).__init__()
        self.startTimerCounter = 0
        self.startWrite2File = False
        self.recordArray = np.zeros([1,4])
        
        self.recordCounter = 0
        self.recordMax = 600
        self.recordMat = np.zeros([self.recordMax,18],dtype=float)
        
        self.recordMat_Mannequin = np.zeros([self.recordMax,8],dtype=float)
        
        self.currentTime = 0
        self.LastTime = 0
        
        #pressure tracking timer
        self.updateTargetTimerInterval = 500 #ms
        #calculate the w in pressure tracking
        #unit: s
        self.T_period = 45 #if we want to set the sin function T as 10 seconds
            
        
        # continuous step response
        # self.stepResponseTargetPressure = np.zeros([48],dtype=float)
        # self.stepResponseTargetPressure[0] = 5
        # self.stepResponseTargetPressure[1] = 10
        # self.stepResponseTargetPressure[2] = 15
        # self.stepResponseTargetPressure[3] = 20
        
        # self.stepResponseTargetPressure[4] = 25
        # self.stepResponseTargetPressure[5] = 30
        # self.stepResponseTargetPressure[6] = 35
        # self.stepResponseTargetPressure[7] = 40
        
        # self.stepResponseTargetPressure[8] = 45
        # self.stepResponseTargetPressure[9] = 50
        # self.stepResponseTargetPressure[10] = 55
        # self.stepResponseTargetPressure[11] = 60
        
        # self.stepResponseTargetPressure[12] = 65
        # self.stepResponseTargetPressure[13] = 70
        # self.stepResponseTargetPressure[14] = 65
        # self.stepResponseTargetPressure[15] = 60
        
        # self.stepResponseTargetPressure[16] = 55
        # self.stepResponseTargetPressure[17] = 50
        # self.stepResponseTargetPressure[18] = 45
        # self.stepResponseTargetPressure[19] = 40
        
        # self.stepResponseTargetPressure[20] = 35
        # self.stepResponseTargetPressure[21] = 30
        # self.stepResponseTargetPressure[22] = 25
        # self.stepResponseTargetPressure[23] = 20
        
        # self.stepResponseTargetPressure[24] = 15
        # self.stepResponseTargetPressure[25] = 10
        # self.stepResponseTargetPressure[26] = 5
        # self.stepResponseTargetPressure[27] = 0
        
        # self.stepResponseTargetPressure[28] = -5
        # self.stepResponseTargetPressure[29] = -10
        # self.stepResponseTargetPressure[30] = -15
        # self.stepResponseTargetPressure[31] = -20
        
        # self.stepResponseTargetPressure[32] = -25
        # self.stepResponseTargetPressure[33] = -30
        # self.stepResponseTargetPressure[34] = -35
        # self.stepResponseTargetPressure[35] = -40
        
        # self.stepResponseTargetPressure[36] = -45
        # self.stepResponseTargetPressure[37] = -50
        # self.stepResponseTargetPressure[38] = -45
        # self.stepResponseTargetPressure[39] = -40
        
        # self.stepResponseTargetPressure[40] = -35
        # self.stepResponseTargetPressure[41] = -30
        # self.stepResponseTargetPressure[42] = -25
        # self.stepResponseTargetPressure[43] = -20
        
        # self.stepResponseTargetPressure[44] = -15
        # self.stepResponseTargetPressure[45] = -10
        # self.stepResponseTargetPressure[46] = -5
        # self.stepResponseTargetPressure[47] = 0
        

        #step response target pressure value
        self.stepResponseTargetPressure = np.zeros([12],dtype=float)
        self.stepResponseTargetPressure[0] = 10
        self.stepResponseTargetPressure[1] = 30
        self.stepResponseTargetPressure[2] = 50
        self.stepResponseTargetPressure[3] = 70
        
        self.stepResponseTargetPressure[4] = 50
        self.stepResponseTargetPressure[5] = 30
        self.stepResponseTargetPressure[6] = 10
        self.stepResponseTargetPressure[7] = -10
        
        self.stepResponseTargetPressure[8] = -30    
        self.stepResponseTargetPressure[9] = -50
        self.stepResponseTargetPressure[10] = -30
        self.stepResponseTargetPressure[11] = -10
        
       
        
        
        self.pressureUpdateTimerCounter = 0
    
    #self.showInfo(
    def showInfo(self, info):
        self.ui.textEdit_info.append(info)
        self.ui.textEdit_info.moveCursor(qtg.QTextCursor.End)
        
    def tryPrint(self):
        self.showInfo("In worker..")
    
    # def __del__(self):
        # try:
            # self.timer.stop()
        # except:
            # pass
    
    
    @pyqtSlot()
    def PauseTimer(self):
        #self.showInfo("Pause Timer...")
        try:
            self.timer.stop()
            print("Pause Receiving Feedback Info..")
        except:
            pass
    
    @pyqtSlot()
    def StartTimer(self):
        if self.startTimerCounter == 0:  
            self.timer = QTimer()
            self.timer.setInterval(2)
            self.timer.timeout.connect(self.DoUpdate)
            self.counterTimer = 0
        
        self.timer.start()
        self.startTimerCounter = self.startTimerCounter + 1
        print("Start Receiving Feedback Info..")
        
    @pyqtSlot()
    def DoUpdate(self):
        #self.showInfo(f"hello {self.counterTimer}")
        self.TimerFunc_Record()
        self.counterTimer = self.counterTimer + 1
        
    #should be ran in other thread
    def TimerFunc_Record(self):
        # # while True:
        # try:
            # start = time.time()
            # #self.showInfo(f"Elaspse time of redrawing takes {(end - start)*1000.0} ms")
            # if self.serial.in_waiting>=1:  
                # self.serial.reset_input_buffer()
                # answer = self.serial.read_until(expected=b"\n").decode("utf-8")
                # if len(answer)<=1:
                    # #self.showInfo("Less than 1 byte")
                    # return
                # if answer[-2:] == "\r\n":
                    # #print(answer)
                    # if answer[0] == "T":
                        # answer = answer[:-2]
                        # #self.ShowInfo(answer)
                        # #15.68,5.00,0,0.00,0.00
                        # end1 = answer.find(',',0)
                        # #                       >=0, <end1
                        # currentP = float(answer[1:end1])
                        # end2 = answer.find(',',end1+1)
                        # targetP = float(answer[end1+1:end2])
                        
                        # end3 = answer.find(',',end2+1)
                        # valvePos = int(answer[end2+1:end3])
                        # end4 = answer.find(',',end3+1)
                        # end5 = answer.find(',',end4+1)
                        # pumpSpeed1 = float(answer[end3+1:end4])
                        # pumpSpeed2 = float(answer[end4+1:end5])
                        # #end6 = answer.find(';',end5+1)
                        # #pressureDerivative = float(answer[end5+1:end6])
                        # #print(f"{currentP}")
                        # self.globalData.mutex.lock()
                        # self.globalData.currentP[0] = currentP
                        # self.globalData.targetP[0] = targetP
                        # self.globalData.inflationPump[0] = pumpSpeed1
                        # self.globalData.deflationPump[0] = pumpSpeed2  
                        # #self.globalData.pressureDerivative[0] = pressureDerivative  
                        
                        # self.globalData.mutex.unlock()
                        
                        
                        # #self.LastTime = 0
                        
                        # #try to record data when necessary
                        # if self.startWrite2File == True:
                            # self.recordMat[self.recordCounter,0] = currentP
                            # self.recordMat[self.recordCounter,1] = targetP
                            # self.recordMat[self.recordCounter,2] = pumpSpeed1*1000.0
                            # self.recordMat[self.recordCounter,3] = pumpSpeed2*1000.0
                            # #self.recordMat[self.recordCounter,4] = pressureDerivative
                            
                            # if self.recordCounter%100==0:
                                # self.currentTime = time.time()
                                # deltaTime = (self.currentTime - self.LastTime)*1000.0
                                # print(f"Time elasps of 100 is {deltaTime} ms")
                                
                                # self.LastTime = self.currentTime
                               
                            
                            # if self.recordCounter>=(self.recordMax-1):
                                # np.savetxt(self.file, self.recordMat,delimiter=",")
                                # self.recordCounter = 0
                                # self.showInfo(f"Already record {self.recordMax} time steps")
                            # else:
                                # self.recordCounter = self.recordCounter+1
                        # #print(f"Decode: {currentP},{targetP},{pumpSpeed1},{pumpSpeed2}")
            # #print(f"Elaspse time of parsing data from board takes {(time.time() - start)*1000.0} ms")
        # except:
            # pass
        # #print("In updating phase")
        # #self.recordTimer.stop()    

 # Soft Gripper
        try:
            start = time.time()
            #self.showInfo(f"Elaspse time of redrawing takes {(end - start)*1000.0} ms")
            if self.serial.in_waiting>=1:  
                self.serial.reset_input_buffer()
                answer = self.serial.read_until(expected=b"\n").decode("utf-8")
                
                
                answer = self.serial.read_until(expected=b"\n").decode("utf-8")
                #print(answer)
                if len(answer)<=1:
                    #self.showInfo("Less than 1 byte")
                    return
                if answer[-2:] == "\r\n":
                    #print(answer)
                    if answer[0] == "T":
                        #print(answer)
                        answer = answer[:-2]
                        #self.ShowInfo(answer)
                        #15.68,5.00,0,0.00,0.00
                        end1 = answer.find(',',0)
                        end2 = answer.find(',',end1+1)
                        end3 = answer.find(',',end2+1)
                        end4 = answer.find(',',end3+1)
                        end5 = answer.find(',',end4+1)
                        end6 = answer.find(',',end5+1)
                        end7 = answer.find(',',end6+1)
                        end8 = answer.find(',',end7+1)
                        end9 = answer.find(',',end8+1)
                        end10 = answer.find(';',end9+1)
                        
                        current0 = float(answer[1:end1])
                        current1 = float(answer[end1+1:end2])
                        current2 = float(answer[end2+1:end3])
                        current3 = float(answer[end3+1:end4])
                        current4 = float(answer[end4+1:end5])
                        current5 = float(answer[end5+1:end6])
                        current6 = float(answer[end6+1:end7])
                        current7 = float(answer[end7+1:end8])
                        current8 = float(answer[end8+1:end9])
                        current9 = float(answer[end9+1:end10])
                        
                        #print(f"Current {current0},{current1},{current2},   {current3},{current4},{current5},  {current6},{current7},{current9}")
                        # end11 = answer.find(',',end9+1)
                        # end12 = answer.find(',',end11+1)
                        # end13 = answer.find(',',end12+1)
                        # end14 = answer.find(',',end13+1)
                        # end15 = answer.find(',',end14+1)
                        # end16 = answer.find(',',end15+1)
                        # end17 = answer.find(',',end16+1)
                        # end18 = answer.find(',',end17+1)
                        # end19 = answer.find(',',end18+1)
                        
                        # target0 = float(answer[end9+1:end11])
                        # target1 = float(answer[end11+1:end12])
                        # target2 = float(answer[end12+1:end13])
                        # target3 = float(answer[end13+1:end14])
                        # target4 = float(answer[end14+1:end15])
                        # target5 = float(answer[end15+1:end16])
                        # target6 = float(answer[end16+1:end17])
                        # target7 = float(answer[end17+1:end18])
                        # target9 = float(answer[end18+1:end19])
                        
                        #end6 = answer.find(';',end5+1)
                        #pressureDerivative = float(answer[end5+1:end6])
                        #print(f"{currentP}")
                        self.globalData.mutex.lock()
                        self.globalData.currentP[0] = current0
                        self.globalData.currentP[1] = current1
                        self.globalData.currentP[2] = current2
                        self.globalData.currentP[3] = current3
                        self.globalData.currentP[4] = current4
                        
                        self.globalData.currentP[5] = current5
                        self.globalData.currentP[6] = current6
                        self.globalData.currentP[7] = current7
                        self.globalData.currentP[8] = current8
                        self.globalData.currentP[9] = current9
                         
                        #self.globalData.pressureDerivative[0] = pressureDerivative  
                        
                        self.globalData.mutex.unlock()
                        
                        #print(f"Target {current0},{current1},{current2},{current3},{current4},   {current5},{current6},{current7},{current8},{current9}")
                        
                        #self.LastTime = 0
                        
                        #try to record data when necessary
                        if self.startWrite2File == True:
                            self.recordMat[self.recordCounter,0] = current0
                            self.recordMat[self.recordCounter,1] = current1
                            self.recordMat[self.recordCounter,2] = current2
                            self.recordMat[self.recordCounter,3] = current3
                            self.recordMat[self.recordCounter,4] = current4
                            self.recordMat[self.recordCounter,5] = current5
                            self.recordMat[self.recordCounter,6] = current6
                            self.recordMat[self.recordCounter,7] = current7
                            self.recordMat[self.recordCounter,8] = current8
                            self.recordMat[self.recordCounter,9] = current9
                            
                            # self.recordMat[self.recordCounter,10] = target1
                            # self.recordMat[self.recordCounter,11] = target2
                            # self.recordMat[self.recordCounter,12] = target3
                            # self.recordMat[self.recordCounter,13] = target4
                            # self.recordMat[self.recordCounter,14] = target5
                            # self.recordMat[self.recordCounter,15] = target6
                            # self.recordMat[self.recordCounter,16] = target7
                            # self.recordMat[self.recordCounter,17] = target9
                            #self.recordMat[self.recordCounter,4] = pressureDerivative
                            
                            if self.recordCounter%100==0:
                                self.currentTime = time.time()
                                deltaTime = (self.currentTime - self.LastTime)*1000.0
                                print(f"Time elasps of 100 is {deltaTime} ms")
                                
                                self.LastTime = self.currentTime
                               
                            
                            if self.recordCounter>=(self.recordMax-1):
                                np.savetxt(self.file, self.recordMat,delimiter=",")
                                self.recordCounter = 0
                                print(f"Already record {self.recordMax} time steps")
                            else:
                                self.recordCounter = self.recordCounter+1
                        #print(f"Decode: {currentP},{targetP},{pumpSpeed1},{pumpSpeed2}")
            #print(f"Elaspse time of parsing data from board takes {(time.time() - start)*1000.0} ms")
        except:
            pass
        #print("In updating phase")
        #self.recordTimer.stop()    

#Mannaequin Situation: Record all required data        
        # # while True:
        # try:
            # start = time.time()
            # #self.showInfo(f"Elaspse time of redrawing takes {(end - start)*1000.0} ms")
            # if self.serial.in_waiting>=1:  
                # self.serial.reset_input_buffer()
                # answer = self.serial.read_until(expected=b"\n").decode("utf-8")
                # if len(answer)<=1:
                    # #self.showInfo("Less than 1 byte")
                    # return
                # if answer[-2:] == "\r\n":
                    # if answer[0] == "T":
                        # answer = answer[:-2]
                        # #self.ShowInfo(answer)
                        # #15.68,5.00,0,0.00,0.00
                        # end1 = answer.find(',',0)
                        # #                       >=0, <end1
                        # currentP0 = float(answer[1:end1])
                        # end2 = answer.find(',',end1+1)
                        # targetP0 = float(answer[end1+1:end2])
                        
                        # end3 = answer.find(',',end2+1)
                        # currentP1 = float(answer[end2+1:end3])
                        # end4 = answer.find(',',end3+1)
                        # targetP1 = float(answer[end3+1:end4])
                        
                        # end5 = answer.find(',',end4+1)
                        # currentP2 = float(answer[end4+1:end5])
                        # end6 = answer.find(',',end5+1)
                        # targetP2 = float(answer[end5+1:end6])
                        
                        
                        # end7 = answer.find(',',end6+1)
                        # end8 = answer.find(';',end7+1)
                        # currentP3 = float(answer[end6+1:end7])
                        # targetP3 = float(answer[end7+1:end8])
                        
                        # #print(f"{currentP0} {currentP1} {currentP2} {currentP3}")
                        # # pressureDerivative = float(answer[end5+1:])
                        
                        # self.globalData.mutex.lock()
                        # self.globalData.currentP[0] = currentP0
                        # self.globalData.targetP[0] = targetP0
                        # self.globalData.inflationPump[0] = 0
                        # self.globalData.deflationPump[0] = 0  
                        # self.globalData.pressureDerivative[0] = 0  
                        
                        # self.globalData.mutex.unlock()
                        
                        
                        # #self.LastTime = 0
                        
                        # #try to record data when necessary
                        # if self.startWrite2File == True:
                            # self.recordMat_Mannequin[self.recordCounter,0] = currentP0
                            # self.recordMat_Mannequin[self.recordCounter,1] = currentP1
                            # self.recordMat_Mannequin[self.recordCounter,2] = currentP2
                            # self.recordMat_Mannequin[self.recordCounter,3] = currentP3
                            # self.recordMat_Mannequin[self.recordCounter,4] = targetP0
                            # self.recordMat_Mannequin[self.recordCounter,5] = targetP1
                            # self.recordMat_Mannequin[self.recordCounter,6] = targetP2
                            # self.recordMat_Mannequin[self.recordCounter,7] = targetP3
                            
                            # if self.recordCounter%100==0:
                                # self.currentTime = time.time()
                                # deltaTime = (self.currentTime - self.LastTime)*1000.0
                                # print(f"Time elasps of 100 is {deltaTime} ms")
                                
                                # self.LastTime = self.currentTime
                               
                            
                            # if self.recordCounter>=(self.recordMax-1):
                                # np.savetxt(self.file, self.recordMat_Mannequin,delimiter=",")
                                # self.recordCounter = 0
                                # self.showInfo(f"Already record {self.recordMax} time steps")
                            # else:
                                # self.recordCounter = self.recordCounter+1
                        # #print(f"Decode: {currentP},{targetP},{pumpSpeed1},{pumpSpeed2}")
            # #print(f"Elaspse time of parsing data from board takes {(time.time() - start)*1000.0} ms")
        # except:
            # pass
        # #print("In updating phase")
        # #self.recordTimer.stop()    
        
    '''
        Connect to OpenPneu in thread
    '''
    @pyqtSlot(int,float)
    def Connect2OpenPneu(self, baudrate,timeout):
        #timeout = 0.3
        self.ui.pushButton_disconnect.setEnabled(True)
        print("baudrate is "+str(baudrate)+f", and timeout is {timeout} second(s)")
        self.serial = serial.Serial()
        time.sleep(1)
        self.serial.baudrate = baudrate
        self.serial.timeout = timeout
        self.plist = list(serial.tools.list_ports.comports())
        #self.showInfo(self.plist[0])
        #self.ShowInfo(self.plist)
        flag_success = False
        if len(self.plist) <= 0: 
            print("no port")
        else:
            
            for port in self.plist:
                plist_0 = list(port)
                portName = plist_0[0]
                print(portName)
                self.serial.port = portName
                self.serial.open()
                time.sleep(1.5) #this delay is waiting for CPU to going into main loop
                print("After Initialization")
                self.serial.reset_input_buffer()
                self.serial.write(bytes("AT+ADDRESS\r\n", 'utf-8'))
                answer = self.serial.read_until(expected=b"\n")
                print("before is: \n"+str(answer))
                answer = answer.decode("utf-8")
                #self.ShowInfo(answer)
                print("Info is: \n"+str(answer))
                if answer == "OpenPneu2.0\r\n":
                    print("Connect to:\nOpenPneu2.0\nRight port, keep connection")
                    
                    flag_success = True
                    self.ui.pushButton_5.setEnabled(True)
                    
                    break
                else:
                    self.serial.reset_input_buffer() 
                    print("Error port, switch to next...")
                
            if flag_success == True:
                self.showInfo("Connection established...\n")
                self.ui.pushButton_connect.setEnabled(False)
            else:
                self.showInfo("No correct port has been found...\n")
    
    '''
        Disconnect with OpenPneu in thread
    '''
    @pyqtSlot()
    def DisConnect2OpenPneu(self):    
        self.serial.close()
        self.ui.pushButton_connect.setEnabled(True)
        self.ui.pushButton_disconnect.setEnabled(False)
        self.showInfo("Port closed..\n")
      
    @pyqtSlot()
    def StartStreaming(self):
        self.command = "C"
        try:
            if self.serial.is_open:
                self.serial.write(bytes(self.command+"\r\n", 'utf-8'))
        except:
            self.showInfo("Except happens, plz check your connection with board...")
            return
        print("Start Streaming")
        
    @pyqtSlot()
    def StopStreaming(self):
        self.command = "V"
        try:
            if self.serial.is_open:
                self.serial.write(bytes(self.command+"\r\n", 'utf-8'))
        except:
            self.showInfo("Except happens, plz check your connection with board...")
            return
        print("Stop Streaming")

    @pyqtSlot()
    def StartWrite2File(self):
        self.startWrite2File = True
        #open the file first 
        self.file = open("./Data/Record.csv", "w")
        self.file.close()
        #self.showInfo("Override old file")
        
        self.file = open("./Data/Record.csv", "a")
        print("Start writing to file...")
        
    @pyqtSlot()
    def PauseWrite2File(self):
        self.startWrite2File = False
        print("Pause writing to file...")
        
    @pyqtSlot()    
    def SendCmd(self):
        
        
        self.command = self.ui.lineEdit_CMD.text()
        try:
            if self.serial.is_open:
                self.serial.reset_input_buffer()
                self.serial.write(bytes(self.command+"\r\n", 'utf-8'))
                #answer = self.serial.read_until(expected=b"\n")
                #self.showInfo("before is: ",answer)
                #answer = answer.decode("utf-8")
                #self.showInfo(f"PC: {self.command}")
                #self.ShowInfo("OpenPneu: "+str(answer))
                #self.showInfo("Info is: ",answer)
                
        except:
            self.showInfo("Except happens, plz check your connection with board...")
    
    @pyqtSlot()    
    def StartPressureTracking(self):
        self.showInfo("Start Pressure Tracking")
        
        if self.pressureUpdateTimerCounter == 0:  
            self.updateTargetTimer = QTimer()
            self.updateTargetTimer.setInterval(self.updateTargetTimerInterval)
            self.updateTargetTimer.timeout.connect(self.DoUpdateTargetPressure)
            self.counterDoUpdateTarget = 0
            
            
            self.W_sin = 2*np.pi/self.T_period    #the calcualted W will be this
            
            
        
        self.updateTargetTimer.start()
        self.pressureUpdateTimerCounter = self.pressureUpdateTimerCounter + 1
    
    #Timer function that updates the target value
    @pyqtSlot()    
    def DoUpdateTargetPressure(self):
        
        
        ####Sin function
        # # unit: second                                        ms
        # timeFromStart = (self.counterDoUpdateTarget * self.updateTargetTimerInterval)/1000.0
        
        # targetPressure = 35*np.sin(self.W_sin*timeFromStart)+35
        # #print(f"targetPressure is {targetPressure}")
        
        # ####Step Response
        # idx = self.counterDoUpdateTarget % 12
        # targetPressure = self.stepResponseTargetPressure[idx]
        # print("Idx: "+str(idx)+f"; Target = {targetPressure} kPa")
        # #self.stepResponseTargetPressure[0] = 10
        
        # self.command = "T="+ str(targetPressure)
        # #print(f"command is {self.command}")
        # try:
            # if self.serial.is_open:
                # #self.serial.reset_input_buffer()
                # self.serial.write(bytes(self.command+"\r\n", 'utf-8'))
                # #answer = self.serial.read_until(expected=b"\n")
                # #print("before is: ",answer)
                # #answer = answer.decode("utf-8")
                # #self.ShowInfo(answer)
                # #print("Info is: ",answer)
                # #print(f"Send {self.command} to OpenPneu...")
        # except:
            # print("Except happens, plz check your connection with board...")
        
        
        
        
        # self.counterDoUpdateTarget = self.counterDoUpdateTarget + 1
    
        ####Continuous Tracking
        #    unit: s                                               unit: ms
        timeFromStart = (self.counterDoUpdateTarget * self.updateTargetTimerInterval)/1000.0
        
        targetPressure = 60*np.sin(self.W_sin*timeFromStart)+10
        # #print(f"targetPressure is {targetPressure}")
        
      
 
        #print("Idx: "+str(idx)+f"; Target = {targetPressure} kPa")
        #self.stepResponseTargetPressure[0] = 10
        print(f"{targetPressure}")
        
        self.command = "T="+ str(targetPressure)
        #print(f"command is {self.command}")
        try:
            if self.serial.is_open:
                #self.serial.reset_input_buffer()
                self.serial.write(bytes(self.command+"\r\n", 'utf-8'))
                #answer = self.serial.read_until(expected=b"\n")
                #print("before is: ",answer)
                #answer = answer.decode("utf-8")
                #self.ShowInfo(answer)
                #print("Info is: ",answer)
                #print(f"Send {self.command} to OpenPneu...")
        except:
            print("Except happens, plz check your connection with board...")
        
        
        
        
        self.counterDoUpdateTarget = self.counterDoUpdateTarget + 1
    
        
    @pyqtSlot()    
    def StopPressureTracking(self):
        self.showInfo("Stop Pressure Tracking")
        self.updateTargetTimer.stop()
    @pyqtSlot(int)   
    def SetTargetPressureChannels(self, channelNo):
        if channelNo ==0:
            value = self.ui.horizontalSlider_C00.value()/10.0
            self.command = "T="+str(value)
            #self.showInfo(self.command)
            try:
                if self.serial.is_open:
                    #self.serial.reset_input_buffer()
                    self.serial.write(bytes(self.command+"\r\n", 'utf-8'))
                    #answer = self.serial.read_until(expected=b"\n")
                    #self.showInfo("before is: ",answer)
                    #answer = answer.decode("utf-8")
                    #self.ShowInfo(answer)
                    #self.showInfo("Info is: ",answer)
                    feedbackName = "Send " + self.command + " to OpenPneu..."
                    print(feedbackName)
                    #self.showInfo(feedbackName)
            except:
                self.showInfo("Except happens, plz check your connection with board...")
            
        if channelNo ==1:
            value = self.ui.horizontalSlider_C01.value()/10.0
            
        if channelNo ==2:
            value = self.ui.horizontalSlider_C02.value()/10.0
        #print(f"On clicked {channelNo} and value is {self.ui.horizontalSlider_C00.value()/10.0}")
        
class WorkerController(qtc.QObject):

    #A signal needs to be defined on class level
    _startTimerSignal = pyqtSignal()
    _pauseTimerSignal = pyqtSignal()
    _connect2BoardSignal = pyqtSignal(int,float)
    _disconnect2BoardSignal =  pyqtSignal()
    
    _startStreamingSignal =  pyqtSignal()
    _stopStreamingSignal =  pyqtSignal()
    
    _startWrite2File =  pyqtSignal()
    _pauseWrite2File =  pyqtSignal()
    
    _sendcmd = pyqtSignal()
    
    _startPressureTracking = pyqtSignal()
    _stopPressureTracking = pyqtSignal()
    
    _setTargetPressureChannels = pyqtSignal(int)
    
    def __init__(self,ui,globalData):
        super(WorkerController,self).__init__()

        self.thread = QThread()
        self.worker = Worker()
        self.worker.ui = ui
        self.worker.globalData = globalData
        self.worker.moveToThread(self.thread)
        
        #####Signal Slot Connection
        
        self._startTimerSignal.connect(self.worker.StartTimer)
        self._pauseTimerSignal.connect(self.worker.PauseTimer)
        self._connect2BoardSignal.connect(self.worker.Connect2OpenPneu)
        self._disconnect2BoardSignal.connect(self.worker.DisConnect2OpenPneu)
        
        self._startStreamingSignal.connect(self.worker.StartStreaming)
        self._stopStreamingSignal.connect(self.worker.StopStreaming)
        
        self._startWrite2File.connect(self.worker.StartWrite2File)
        self._pauseWrite2File.connect(self.worker.PauseWrite2File)
        
        self._sendcmd.connect(self.worker.SendCmd)
        
        self._startPressureTracking.connect(self.worker.StartPressureTracking)
        self._stopPressureTracking.connect(self.worker.StopPressureTracking)
   
        self._setTargetPressureChannels.connect(self.worker.SetTargetPressureChannels)
        #connect(&workerThread, &QThread::finished, worker, &QObject::deleteLater);
        
        #self.thread.finished.connect()
        self.thread.start();
    
    
    
    @pyqtSlot()
    def StartTimer(self):
        self._startTimerSignal.emit()
    
    @pyqtSlot()
    def StopTimer(self):
        self._pauseTimerSignal.emit()
    
    def Connect2Board(self, baudrate = 115200,timeout = 0.5):
        #print(f"In Ctrller, baudrate is {baudrate}")
        self._connect2BoardSignal.emit(baudrate,timeout)
    
    def Disconnect2Board(self):
        self._disconnect2BoardSignal.emit()
    
    def StartStreaming(self):
        self._startStreamingSignal.emit()
        
    def StopStreaming(self):
        self._stopStreamingSignal.emit()
        
    def StartWrite2File(self):
        self._startWrite2File.emit()
        
    def PauseWrite2File(self):
        self._pauseWrite2File.emit()
        
    def SendCmd(self):
        self._sendcmd.emit()

    def StartPressureTracking(self):
        self._startPressureTracking.emit()
    
    def StopPressureTracking(self):
        self._stopPressureTracking.emit()
        
    #channelNo is from 0 to 9
    def SetTargetPressure(self,cNo):
        self._setTargetPressureChannels.emit(cNo)