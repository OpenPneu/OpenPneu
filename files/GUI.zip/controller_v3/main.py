# coding: utf-8
import sys
from PyQt5 import QtWidgets as qtw
from PyQt5 import QtCore as qtc
from PyQt5 import QtGui as qtg
from PyQt5.QtWidgets import *
from PyQt5.QtCore import QTimer, QDateTime,pyqtSignal,QThread
from monitorUI import Ui_MainWindow
from pressurem import Ui_PressureM
import time
import numpy as np
import serial
import qdarkstyle 
import serial.tools.list_ports
import plotMonitor
import openPneuThread


import ctypes
myappid = 'mycompany.myproduct.subproduct.version' # arbitrary string
ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
counter = 1

##global variable used to indicate plot Monitor has been activated
flag_PlotMonitorInit = False



#Pressure Monitor UI
class PressureM(qtw.QMainWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.ui = Ui_PressureM()
        self.ui.setupUi(self)
        self.setWindowTitle("Pressure Monitor")
        self.setWindowIcon(qtg.QIcon('iconCat.jpg'))
    
        self.setGeometry(100, 900, self.width(), self.height())
        #signal-slot connection
        self.ui.pushButton_C0.released.connect(self.GeneratePlotMonitor)
        self.plotMonitorCounter = 0
        
        #
        self.ui.widget.setMinValue(-100)
        self.ui.widget_2.setMinValue(-100)
        self.ui.widget_3.setMinValue(-100)
        self.ui.widget_4.setMinValue(-100)
        self.ui.widget_5.setMinValue(-100)
        
    # def closeEvent(self, event):
        # if self.plotMonitor:
            # self.plotMonitor.close()    
    #update 
    def GeneratePlotMonitor(self):
        if (self.sender()==self.ui.pushButton_C0):
            plotname = 'Channel No.0'
        self.plotMonitor = plotMonitor.MainWindow(PlotName = plotname)
        self.plotMonitor.show()
        
        #self.plotMonitor.updateOnce(currentPressure,targetPressure,flowRateInflation,flowRateDeflation)
        
        global flag_PlotMonitorInit
        flag_PlotMonitorInit = True
        # if self.plotMonitorCounter%2==1:
            # print("Close plot monitor")
            # self.plotMonitor.close()
        # self.plotMonitorCounter = self.plotMonitorCounter + 1    
    def openPlotMonitor2(self):
        pass
    
#when want to show info in the left textedit, use 
#self.ui.textEdit_info.append(str())
#Control Panel UI

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        
        self.setWindowTitle("OpenPneu")
        self.setWindowIcon(qtg.QIcon('iconCat.jpg'))
        
        self.setGeometry(1500, 100, self.width(), self.height())
        
        self.ui.pushButton_4.setEnabled(False)
        self.ui.pushButton_5.setEnabled(False)
        
        self.ui.pushButton_connect.released.connect(self.Connect)
        self.ui.pushButton_disconnect.released.connect(self.Disconnect)
        self.ui.pushButton_Send.released.connect(self.SendCmd)
        
        self.ui.pushButton_StartRecording.released.connect(self.StartRecordData)
        self.ui.pushButton_PauseRecording.released.connect(self.PauseRecordData)
        
        
        self.ui.pushButton_startStreaming.released.connect(self.StartStreaming)
        self.ui.pushButton_pauseStreaming.released.connect(self.StopStreaming)
        
        self.ui.pushButton_startWrite2File.released.connect(self.StartWrite2File)
        self.ui.pushButton_pauseWrite2File.released.connect(self.PauseWrite2File)
        
        self.ui.pushButton_startPressureTracking.released.connect(self.StartPressureTracking)
        self.ui.pushButton_stopPressureTracking.released.connect(self.StopPressureTracking)
        
        
        
        
        self.recordCounter = 0
        
        #thread controller that handles all threads
        self.globalData = openPneuThread.globalDataSet()
        self.workerCtrller = openPneuThread.WorkerController(self.ui, self.globalData)
        
        # self.globalData.mutex.lock()
        # self.globalData.currentP[0] = np.random.random_sample()
        # self.globalData.mutex.unlock()
        
        
        #slider that changes the target pressure value
        self.ui.horizontalSlider_C00.valueChanged.connect(self.updateLCD)
        self.ui.horizontalSlider_C01.valueChanged.connect(self.updateLCD)
        self.ui.horizontalSlider_C02.valueChanged.connect(self.updateLCD)
        self.ui.horizontalSlider_C03.valueChanged.connect(self.updateLCD)
        self.ui.horizontalSlider_C04.valueChanged.connect(self.updateLCD)
        
        self.ui.horizontalSlider_C05.valueChanged.connect(self.updateLCD)
        self.ui.horizontalSlider_C06.valueChanged.connect(self.updateLCD)
        self.ui.horizontalSlider_C07.valueChanged.connect(self.updateLCD)
        self.ui.horizontalSlider_C08.valueChanged.connect(self.updateLCD)
        self.ui.horizontalSlider_C09.valueChanged.connect(self.updateLCD)
        
        #set button that sends the target pressure to board
        self.ui.pushButton_Set_C00.released.connect(self.SetTargetPressure_OnClicked)
        self.ui.pushButton_Set_C01.released.connect(self.SetTargetPressure_OnClicked)
        self.ui.pushButton_Set_C02.released.connect(self.SetTargetPressure_OnClicked)
        self.ui.pushButton_Set_C03.released.connect(self.SetTargetPressure_OnClicked)
        self.ui.pushButton_Set_C04.released.connect(self.SetTargetPressure_OnClicked)
        
        self.ui.pushButton_Set_C05.released.connect(self.SetTargetPressure_OnClicked)
        self.ui.pushButton_Set_C06.released.connect(self.SetTargetPressure_OnClicked)
        self.ui.pushButton_Set_C07.released.connect(self.SetTargetPressure_OnClicked)
        self.ui.pushButton_Set_C08.released.connect(self.SetTargetPressure_OnClicked)
        self.ui.pushButton_Set_C09.released.connect(self.SetTargetPressure_OnClicked)
        
        
        self.currenPressureArray = np.zeros([10],dtype=float)
        
    def updateLCD(self, event):
        if self.sender()==self.ui.horizontalSlider_C00:
            self.ui.lcdNumber_C00.display(event/10.0)
        if self.sender()==self.ui.horizontalSlider_C01:
            self.ui.lcdNumber_C01.display(event/10.0)
        if self.sender()==self.ui.horizontalSlider_C02:
            self.ui.lcdNumber_C02.display(event/10.0)
        if self.sender()==self.ui.horizontalSlider_C03:
            self.ui.lcdNumber_C03.display(event/10.0)
        if self.sender()==self.ui.horizontalSlider_C04:
            self.ui.lcdNumber_C04.display(event/10.0)
            
        if self.sender()==self.ui.horizontalSlider_C05:
            self.ui.lcdNumber_C05.display(event/10.0)
        if self.sender()==self.ui.horizontalSlider_C06:
            self.ui.lcdNumber_C06.display(event/10.0)
        if self.sender()==self.ui.horizontalSlider_C07:
            self.ui.lcdNumber_C07.display(event/10.0)
        if self.sender()==self.ui.horizontalSlider_C08:
            self.ui.lcdNumber_C08.display(event/10.0)
        if self.sender()==self.ui.horizontalSlider_C09:
            self.ui.lcdNumber_C09.display(event/10.0)
    
    def SetTargetPressure_OnClicked(self):
        if self.sender()==self.ui.pushButton_Set_C00:
            #print("Click on set C00")
            self.workerCtrller.SetTargetPressure(0)
            
        if self.sender()==self.ui.pushButton_Set_C01:
            self.workerCtrller.SetTargetPressure(1)
            #print("Click on set C01")
        if self.sender()==self.ui.pushButton_Set_C02:
            self.workerCtrller.SetTargetPressure(2)
            #print("Click on set C02")
    
    def StartPressureTracking(self):
        self.workerCtrller.StartPressureTracking()
    
    def StopPressureTracking(self):
        self.workerCtrller.StopPressureTracking()
            
    def SendCmd(self):
        
        self.workerCtrller.SendCmd()
        
        
        
    #If want to show info in the left textedit, use self.ShowInfo(string type)
    def ShowInfo(self, info):
        self.ui.textEdit_info.append(info)
        
    def Connect(self):
        self.workerCtrller.Connect2Board(115200,0.5)
  
    def Disconnect(self):
    
        self.workerCtrller.Disconnect2Board()
        # self.serial.close()
        # self.ui.pushButton_connect.setEnabled(True)
        # self.ui.pushButton_disconnect.setEnabled(False)
        # self.ShowInfo("Port closed..\n")
    #pushButton_startStreaming
    
    def StartStreaming(self):
        self.workerCtrller.StartStreaming()
    
    def StopStreaming(self):
        self.workerCtrller.StopStreaming()
    
    # def UpdateClock(self):
        # pass

    def write_read(self,x):
        self.arduino = serial.Serial(port='/dev/cu.usbmodem1201', baudrate=115200, timeout=.1)
        self.arduino.write(bytes(x, 'utf-8'))
        time.sleep(0.05)
        self.data = self.arduino.readline()
        return self.data

    def OnRelease_Run(self):
        #readData = np.loadtxt("testPressureData.txt")
        #timer definition
        self.timer = QTimer()
        self.timer.setInterval(10)
        self.timer.timeout.connect(self.Update_pressureMonitor_plotMonitor)
        self.counterTimer = 0
        self.timer.start()
        
        self.ui.pushButton_3.setEnabled(True)
        self.ui.pushButton_4.setEnabled(False)
     
    #After click on RUN, you will run this function
    def Update_pressureMonitor_plotMonitor(self):
        if self.w.isVisible():
            pass
        else:
            self.OnRelease_Stop()
            self.ShowInfo("Pressur monitor already closed, timer will stop...")
            return
        try:
        
            # self.globalData.mutex.lock()
            # currentP = self.globalData.currentP[0] 
            # targetP = self.globalData.targetP[0] 
            # pumpSpeed1 = self.globalData.inflationPump[0] 
            # pumpSpeed2 = self.globalData.deflationPump[0] 
            # pressureDerivative = self.globalData.pressureDerivative[0]
            
            # self.globalData.mutex.unlock()
            
            # self.counterTimer = self.counterTimer + 1
            # if self.counterTimer >= 120:
                # self.counterTimer = 0

            # self.w.ui.widget.updateValue(currentP)
        
            # #update plot monitor values
            # global flag_PlotMonitorInit
            # if flag_PlotMonitorInit == True:
                # self.w.plotMonitor.updateOnce(currentP,targetP,pumpSpeed1,pumpSpeed2,pressureDerivative)
                
                # pass
                # #print("RUNNN")
            # else:
                # pass
                # #print("NOT RUN")
                
            ##############################################################    
            ##############################################################    
            self.globalData.mutex.lock()
            currentP = self.globalData.currentP[0] 
            for i in range(10):
                self.currenPressureArray[i] = self.globalData.currentP[i]
            
            targetP = self.globalData.targetP[0] 
            pumpSpeed1 = self.globalData.inflationPump[0] 
            pumpSpeed2 = self.globalData.deflationPump[0] 
            pressureDerivative = self.globalData.pressureDerivative[0]
            
            self.globalData.mutex.unlock()
            
            self.counterTimer = self.counterTimer + 1
            if self.counterTimer >= 120:
                self.counterTimer = 0

            self.w.ui.widget.updateValue(self.currenPressureArray[0])
            self.w.ui.widget_2.updateValue(self.currenPressureArray[1])
            self.w.ui.widget_3.updateValue(self.currenPressureArray[2])
            self.w.ui.widget_4.updateValue(self.currenPressureArray[3])
            self.w.ui.widget_5.updateValue(self.currenPressureArray[4])
            
            self.w.ui.widget_6.updateValue(self.currenPressureArray[5])
            self.w.ui.widget_7.updateValue(self.currenPressureArray[6])
            self.w.ui.widget_8.updateValue(self.currenPressureArray[7])
            self.w.ui.widget_9.updateValue(self.currenPressureArray[8])
            self.w.ui.widget_10.updateValue(self.currenPressureArray[9])
        
            #update plot monitor values
            global flag_PlotMonitorInit
            if flag_PlotMonitorInit == True:
                # self.w.plotMonitor.updateOnce(currentP,targetP,pumpSpeed1,pumpSpeed2,pressureDerivative)
                
                
                self.w.plotMonitor.updateCurrentPressure(self.currenPressureArray)
                pass
                #print("RUNNN")
            else:
                pass
                #print("NOT RUN")
                
                
        except:
            pass
            
    def OnRelease_Stop(self):
        self.timer.stop()
        self.ui.pushButton_3.setEnabled(False)
        self.ui.pushButton_4.setEnabled(True)
        
        

    def OnRelease_Low(self):
        pass

    def OnRelease_High(self):
        pass

    def OnRelease_Connect(self):
        pass

    def OnRelease_Disconnect(self):
        pass

    #open the dial plate
    def OnRelease_Open(self):
        self.w = PressureM()
        self.w.show()
        self.ui.pushButton_4.setEnabled(True)

    def OnRelease_Close(self):
        self.w.close()
    
    #start timer in thread to record the information from OpenPneu
    def StartRecordData(self):
        self.workerCtrller.StartTimer()
    
    #pause timer of recording information in thread      
    def PauseRecordData(self):
        self.workerCtrller.StopTimer()


    
    def StartWrite2File(self):
        self.workerCtrller.StartWrite2File()
    
    def PauseWrite2File(self):
        self.workerCtrller.PauseWrite2File()

    #function will be called before close this class
    def closeEvent(self, event):
        try:
            if self.w.plotMonitor:
                self.w.plotMonitor.close()
        except:
            pass

        try:
            if self.w:
                self.w.close()
        except:
            pass     
            
        try: 
            self.workerCtrller.StopTimer()
        except:
            pass

if __name__ == '__main__':
    app = QApplication([])
    #import pyqtcss
    #pyqtcss.available_styles()
    #['classic', 'dark_blue', 'dark_orange']
    #style_string = pyqtcss.get_style("classic")
    #app.setStyleSheet(style_string)   #dark style
    # app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())   #dark style
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())