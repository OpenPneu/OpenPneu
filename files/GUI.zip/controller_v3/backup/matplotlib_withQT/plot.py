import sys
import matplotlib
import matplotlib.pyplot as plt
from PyQt5 import QtGui as qtg
from PyQt5 import QtCore, QtWidgets
from random import random
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.figure import Figure

matplotlib.use('Qt5Agg')
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
class MplCanvas(FigureCanvasQTAgg):

    def __init__(self, parent=None, width=1, height=1, dpi=1):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        super(MplCanvas, self).__init__(self.fig)
    def updateFig(self):
        self.fig.canvas.draw()
    def clean(self):
        self.fig.clean()

class MainWindow(QtWidgets.QMainWindow):

    def __init__(self, PlotName = "Plot Monitor", *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        # Create the maptlotlib FigureCanvas object,
        # which defines a single set of axes as self.axes.
        self.sc = MplCanvas(self, width=16, height=9, dpi=150)
        self.xlist = [0]
        self.ylist = [0]
        
        self.sc.axes.plot(self.xlist, self.ylist)
        self.setCentralWidget(self.sc)
        
        self.sc.axes.set_xlim([0, 50])
        self.sc.axes.set_ylim([0, 100])
        
        self.setWindowTitle(PlotName)
        self.setWindowIcon(qtg.QIcon('iconCat.jpg'))
    
        self.sc.axes.spines['right'].set_visible(False)
        self.sc.axes.spines['top'].set_visible(False)

        
        self.show()
        
        fps = 50
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.setInterval(1000 / fps)
        self.timer.start()
        self.counter = 0
        
        self.timerCounter = 0
        
        self.xlist = []
        self.currentPressurelist = []
        self.targetPressureylist = []
        self.flowRateInflationlist = []
        self.flowRateDeflationlist = []
        
    def update(self):
    
        self.sc.axes.cla()
        
        examplex = self.counter
        currentPressure = random()*80
        targetPressure = random()*80
        flowRateInflation = random()*20
        flowRateDeflation = random()*20
        
        if self.counter>=50:
            self.currentPressurelist.pop(0)
            self.targetPressureylist.pop(0)
            self.flowRateInflationlist.pop(0)
            self.flowRateDeflationlist.pop(0)
            
        else:
            self.xlist.append(examplex)
            
        #current pressure place in exampley
        
        
        
        self.currentPressurelist.append(currentPressure)
        self.targetPressureylist.append(targetPressure)
        self.flowRateInflationlist.append(flowRateInflation)
        self.flowRateDeflationlist.append(flowRateDeflation)
 
        self.sc.axes.plot(self.xlist, self.currentPressurelist, label='Current Pressure')
        self.sc.axes.plot(self.xlist, self.targetPressureylist, label='Target Pressure')
        self.sc.axes.plot(self.xlist, self.flowRateInflationlist, label='Inflation Flowrate')
        self.sc.axes.plot(self.xlist, self.flowRateDeflationlist, label='Deflation Flowrate')
        
        self.sc.axes.set_xlim([0, 50])
        self.sc.axes.set_ylim([0, 100])
        self.sc.axes.legend(loc = 'upper right')
        self.sc.updateFig()
        self.counter =  self.counter + 1
        
    def Stop():
        self.timer.stop()
if __name__ == "__main__":   
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    app.exec_()