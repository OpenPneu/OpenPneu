# coding: utf-8
import sys
from PyQt5 import QtWidgets as qtw
from PyQt5 import QtCore as qtc
from PyQt5 import QtGui as qtg
from PyQt5.QtWidgets import *
from PyQt5.QtCore import QTimer, QDateTime
from monitorUI import Ui_MainWindow
from pressurem import Ui_PressureM
import time
import numpy as np
#import serial
import qdarkstyle 
from deviceComScript import MySerial
import serial.tools.list_ports
import plotMonitor


import ctypes
myappid = 'mycompany.myproduct.subproduct.version' # arbitrary string
ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
counter = 1

#Pressure Monitor UI
class PressureM(qtw.QMainWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.ui = Ui_PressureM()
        self.ui.setupUi(self)
        self.setWindowTitle("Pressure Monitor")
        self.setWindowIcon(qtg.QIcon('iconCat.jpg'))
    
        #signal-slot connection
        self.ui.pushButton_C0.released.connect(self.GeneratePlotMonitor)
        self.plotMonitorCounter = 0
        
    #update 
    def GeneratePlotMonitor(self):
        if (self.sender()==self.ui.pushButton_C0):
            plotname = 'Channel No.0'
        self.plotMonitor = plotMonitor.MainWindow(PlotName = plotname)
        self.plotMonitor.show()
        
        # if self.plotMonitorCounter%2==1:
            # print("Close plot monitor")
            # self.plotMonitor.close()
        # self.plotMonitorCounter = self.plotMonitorCounter + 1    
    def openPlotMonitor2(self):
        pass
    
#when want to show info in the left textedit, use 
#self.ui.textEdit_info.append(str())
#Control Panel UI
class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        
        self.setWindowTitle("OpenPneu")
        self.setWindowIcon(qtg.QIcon('iconCat.jpg'))
        
        
        
        self.ui.pushButton_connect.released.connect(self.Connect)
        self.ui.pushButton_disconnect.released.connect(self.Disconnect)

    #If want to show info in the left textedit, use self.ShowInfo(string type)
    def ShowInfo(self, info):
        self.ui.textEdit_info.append(info)
        
    def Connect(self):
        self.ui.pushButton_disconnect.setEnabled(True)
        self.serial = MySerial(
            port=None,
            baudrate=9600, 
            #bytesize=EIGHTBITS, 
            #parity=PARITY_NONE, 
            #stopbits=STOPBITS_ONE, 
            timeout=0.2, 
            xonxoff=False,
            rtscts=False,
            write_timeout=0.5, 
            dsrdtr=False,
            inter_byte_timeout=None,
            exclusive=None)
            
        if self.serial.is_open is True: 
            self.serial.close()
            
        #get serial port list
        self.plist = list(serial.tools.list_ports.comports())
        #self.ShowInfo(self.plist)
        if len(self.plist) <= 0: # 无串口
            self.ShowInfo("no port")
        else:
            # plist_0 = list(self.plist[0])
            # self.ShowInfo(plist_0[0])
            
            #traverse all serial ports and find the right port
            flag_success = False
            for port in self.plist:
                plist_0 = list(port)
                portName = plist_0[0]
                #self.ShowInfo(plist_0[0])
                self.serial.port = portName
                self.serial.open()
                self.serial.reset_input_buffer()
                
                self.serial.write(b"AT+ADDRESS\r\n")
                answer = self.serial.read_until().decode("utf-8")
                #self.ShowInfo(answer)
                if answer == "OpenPneu2.0\r\n":
                    self.ShowInfo("Connect to:\nOpenPneu2.0\nRight port, keep connection")
                    flag_success = True
                    break
                else:
                    self.serial.reset_input_buffer() 
                    self.ShowInfo("Error port, switch to next...")
                
            if flag_success == True:
                self.ShowInfo("Connection established...\n")
                self.ui.pushButton_connect.setEnabled(False)
            else:
                self.ShowInfo("No correct port has been found...\n")
             
    def Disconnect(self):
        self.serial.close()
        self.ui.pushButton_connect.setEnabled(True)
        self.ui.pushButton_disconnect.setEnabled(False)
        self.ShowInfo("Port closed..\n")
        
    def UpdateClock(self):
        pass

    def write_read(self,x):
        self.arduino = serial.Serial(port='/dev/cu.usbmodem1201', baudrate=115200, timeout=.1)
        self.arduino.write(bytes(x, 'utf-8'))
        time.sleep(0.05)
        self.data = self.arduino.readline()
        return self.data

    def OnRelease_Run(self):
        #readData = np.loadtxt("testPressureData.txt")
        #timer definition
        self.timer = QTimer()
        self.timer.setInterval(500)
        self.timer.timeout.connect(self.lcdUpdate)
        self.counterTimer = 0
        self.timer.start()
        
        
        
        


    def lcdUpdate(self):
        if self.serial.is_open is False:
            self.ShowInfo("Port not open, try later..\n")
            return
        
        self.serial.reset_input_buffer()
        self.serial.write(b"AT+UPDATE\r\n")
        answer = self.serial.read_until().decode("utf-8")
        #self.ShowInfo(answer)
        flag_success = False
        if answer[-2:] == "\r\n":
            self.ShowInfo("Read data already...")
            flag_success = True
            
        else:
            self.serial.reset_input_buffer() 
            self.ShowInfo("Error message...")
        
        answer = answer[:-2]
        self.ShowInfo(answer)
        #15.68,5.00,0,0.00,0.00
        end1 = answer.find(',',0)
        #                       >=0, <end1
        currentP = float(answer[0:end1])
        end2 = answer.find(',',end1+1)
        targetP = float(answer[end1+1:end2])
        
        end3 = answer.find(',',end2+1)
        valvePos = int(answer[end2+1:end3])
        end4 = answer.find(',',end3+1)
        pumpSpeed1 = float(answer[end3+1:end4])
        pumpSpeed2 = float(answer[end4+1:])
        
        # print(currentP)
        # print(targetP)
        # print(valvePos)
        # print(pumpSpeed1)
        # print(pumpSpeed2)
    
    
    
    
        self.counterTimer = self.counterTimer + 1
        if self.counterTimer >= 120:
            self.counterTimer = 0

        self.w.ui.widget.updateValue(currentP)
        # self.w.ui.widget_2.updateValue(self.readData_global[self.counterTimer, 1])
        # self.w.ui.widget_3.updateValue(self.readData_global[self.counterTimer, 2])
        # self.w.ui.widget_4.updateValue(self.readData_global[self.counterTimer, 3])
        # self.w.ui.widget_5.updateValue(self.readData_global[self.counter, 4])
        # self.w.ui.widget_6.updateValue(self.readData_global[self.counter, 5])
        # self.w.ui.widget_7.updateValue(self.readData_global[self.counter, 6])
        # self.w.ui.widget_8.updateValue()
        # self.w.ui.widget_9.updateValue()
        # self.w.ui.widget_10.updateValue()

        # print(self.readData_global[self.counter, 1])

    def OnRelease_Stop(self):
        self.timer.stop()

    def OnRelease_Low(self):
        self.ui.plainTextEdit.setPlainText("nunu")

    def OnRelease_High(self):
        self.ui.plainTextEdit.setPlainText("nunu")

    def OnRelease_Connect(self):
        self.ui.plainTextEdit.setPlainText("nunu")

    def OnRelease_Disconnect(self):
        self.ui.plainTextEdit.setPlainText("nunu")

    #open the dial plate
    def OnRelease_Open(self):
        self.w = PressureM()
        self.w.show()

    def OnRelease_Close(self):
        self.w.close()
    
    #open the matplotlib widget





if __name__ == '__main__':
    app = QApplication([])
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())   #dark style
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())